#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
CONFIG_FILE="$SCRIPT_DIR/config.env"

expand_path() {
  local p="${1:-}"
  if [[ -z "$p" ]]; then
    return 0
  fi
  if [[ "$p" == "~" ]]; then
    printf '%s\n' "$HOME"
    return 0
  fi
  if [[ "$p" == ~/* ]]; then
    printf '%s\n' "$HOME/${p#~/}"
    return 0
  fi
  if [[ "$p" == /* ]]; then
    printf '%s\n' "$p"
    return 0
  fi
  printf '%s\n' "$PROJECT_ROOT/$p"
}

log() {
  printf '[%s] %s\n' "$(date +%H:%M:%S)" "$*"
}

load_config() {
  if [[ ! -f "$CONFIG_FILE" ]]; then
    echo "[ERROR] Missing config file: $CONFIG_FILE" >&2
    exit 1
  fi

  # shellcheck disable=SC1090
  source "$CONFIG_FILE"

  SESSION_NAME="${SESSION_NAME:-px4_minimal}"
  PX4_DIR="$(expand_path "${PX4_DIR:-}")"
  ROS_WS="$(expand_path "${ROS_WS:-}")"
  QGC_APPIMAGE="$(expand_path "${QGC_APPIMAGE:-}")"
  RUNTIME_DIR="$(expand_path "${RUNTIME_DIR:-.px4_minimal_run}")"

  PX4_TARGET="${PX4_TARGET:-gz_x500}"
  HEADLESS="${HEADLESS:-0}"

  ENABLE_AGENT="${ENABLE_AGENT:-1}"
  AGENT_CMD="${AGENT_CMD:-/usr/local/bin/MicroXRCEAgent}"
  AGENT_ARGS="${AGENT_ARGS:-udp4 -p 8888}"
  AGENT_START_WAIT_SECONDS="${AGENT_START_WAIT_SECONDS:-2}"

  ENABLE_QGC="${ENABLE_QGC:-1}"
  QGC_ENV="${QGC_ENV:-}"
  QGC_START_WAIT_SECONDS="${QGC_START_WAIT_SECONDS:-3}"

  ENABLE_ROS="${ENABLE_ROS:-1}"
  ROS_DISTRO="${ROS_DISTRO:-jazzy}"
  ROS_SETUP_EXTRA="${ROS_SETUP_EXTRA:-}"
  OFFBOARD_CMD="${OFFBOARD_CMD:-ros2 run my_px4_offboard offboard_trajectory}"
  ROS_START_WAIT_SECONDS="${ROS_START_WAIT_SECONDS:-2}"

  PX4_START_WAIT_SECONDS="${PX4_START_WAIT_SECONDS:-18}"
  PX4_PROCESS_WAIT_SECONDS="${PX4_PROCESS_WAIT_SECONDS:-25}"
  GZ_PROCESS_WAIT_SECONDS="${GZ_PROCESS_WAIT_SECONDS:-25}"
}

ensure_runtime_dir() {
  mkdir -p "$RUNTIME_DIR"
}

pid_file() {
  local name="$1"
  printf '%s/%s.pid\n' "$RUNTIME_DIR" "$name"
}

write_pid() {
  local name="$1"
  local pid="$2"
  printf '%s\n' "$pid" > "$(pid_file "$name")"
}

read_pid() {
  local name="$1"
  local f
  f="$(pid_file "$name")"
  [[ -f "$f" ]] || return 1
  cat "$f"
}

remove_pid() {
  rm -f "$(pid_file "$1")"
}

pid_is_running() {
  local pid="${1:-}"
  [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null
}

component_running() {
  local name="$1"
  local pid
  pid="$(read_pid "$name" 2>/dev/null || true)"
  pid_is_running "$pid"
}

wait_for_pattern_process() {
  local pattern="$1"
  local timeout="$2"
  local label="$3"
  local start_ts now_ts
  start_ts="$(date +%s)"
  while true; do
    if pgrep -fa "$pattern" >/dev/null 2>&1; then
      log "[OK] $label"
      return 0
    fi
    now_ts="$(date +%s)"
    if (( now_ts - start_ts >= timeout )); then
      log "[ERROR] Timeout waiting for $label"
      log "[ERROR] pattern=$pattern"
      return 1
    fi
    sleep 1
  done
}

ensure_prereqs() {
  [[ -d "$PX4_DIR" ]] || { echo "[ERROR] PX4_DIR not found: $PX4_DIR" >&2; exit 1; }

  if [[ "$ENABLE_AGENT" == "1" ]]; then
    command -v "${AGENT_CMD%% *}" >/dev/null 2>&1 || {
      echo "[ERROR] Agent command not found: $AGENT_CMD" >&2
      exit 1
    }
  fi

  if [[ "$ENABLE_QGC" == "1" ]]; then
    [[ -x "$QGC_APPIMAGE" ]] || {
      echo "[ERROR] QGC_APPIMAGE not executable: $QGC_APPIMAGE" >&2
      exit 1
    }
  fi

  if [[ "$ENABLE_ROS" == "1" ]]; then
    [[ -d "$ROS_WS" ]] || {
      echo "[ERROR] ROS_WS not found: $ROS_WS" >&2
      exit 1
    }
    [[ -f "/opt/ros/$ROS_DISTRO/setup.bash" ]] || {
      echo "[ERROR] ROS setup not found: /opt/ros/$ROS_DISTRO/setup.bash" >&2
      exit 1
    }
    if [[ ! -f "$ROS_WS/install/setup.bash" && ! -f "$ROS_WS/install/local_setup.bash" ]]; then
      echo "[ERROR] ROS workspace install setup not found under: $ROS_WS/install" >&2
      exit 1
    fi
  fi
}

cleanup_pattern() {
  local label="$1"
  local pattern="$2"
  if pgrep -fa "$pattern" >/dev/null 2>&1; then
    log "[INFO] stopping $label"
    pkill -f "$pattern" 2>/dev/null || true
    sleep 1
    pkill -9 -f "$pattern" 2>/dev/null || true
  fi
}

start_background() {
  local name="$1"
  local cmd="$2"

  if component_running "$name"; then
    log "[WARN] $name already running (pid $(read_pid "$name"))."
    return 0
  fi

  nohup bash -lc "$cmd" >/dev/null 2>&1 &
  local pid=$!
  write_pid "$name" "$pid"
  log "[OK] started $name (pid $pid)"
}

stop_by_pidfile() {
  local name="$1"
  local pid
  pid="$(read_pid "$name" 2>/dev/null || true)"
  if [[ -z "$pid" ]]; then
    return 0
  fi

  if pid_is_running "$pid"; then
    kill "$pid" 2>/dev/null || true
    sleep 1
    if pid_is_running "$pid"; then
      kill -9 "$pid" 2>/dev/null || true
    fi
  fi
  remove_pid "$name"
}
