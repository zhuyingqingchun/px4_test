Minimal PX4 scripts, no custom logging system.

Default behavior:
- Agent ON
- QGroundControl ON
- ROS offboard ON

Startup order:
1. Agent
2. PX4 + Gazebo
3. Wait for PX4 process and Gazebo process
4. Extra stabilization delay
5. QGroundControl
6. ROS offboard

Usage:
  cd ~/PX4_pro/px4sh
  ./start.sh
  ./stop.sh
  ./restart.sh

No custom stream_log.sh, no summary logs, no alert logs.
