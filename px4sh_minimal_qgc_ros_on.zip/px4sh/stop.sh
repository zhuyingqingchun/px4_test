#!/usr/bin/env bash
set -Eeuo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"

load_config
ensure_runtime_dir

log "[INFO] stopping PX4 minimal stack"

# Stop in reverse dependency order
stop_by_pidfile ros
stop_by_pidfile qgc
stop_by_pidfile px4
stop_by_pidfile agent

# Extra cleanup in case child processes outlive recorded PIDs
cleanup_pattern "ROS offboard app" "offboard_trajectory|offboard_takeoff_hover|ros2 run my_px4_offboard"
cleanup_pattern "QGroundControl" "QGroundControl"
cleanup_pattern "Micro XRCE-DDS Agent" "MicroXRCEAgent|micro-xrce-dds-agent"
cleanup_pattern "PX4" "px4_sitl_default/bin/px4|[ /]px4([[:space:]]|$)"
cleanup_pattern "Gazebo GUI" "gz[[:space:]]+sim[[:space:]]+-g|gz[[:space:]]+gui|gzclient"
cleanup_pattern "Gazebo server" "gz[[:space:]]+sim|gzserver|ign[[:space:]]+gazebo"

rm -f "$(pid_file ros)" "$(pid_file qgc)" "$(pid_file px4)" "$(pid_file agent)"
log "[OK] stop sequence finished"
