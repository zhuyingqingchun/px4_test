#!/usr/bin/env bash
set -Eeuo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"

load_config
ensure_runtime_dir
ensure_prereqs

if component_running px4; then
  log "[WARN] PX4 stack already appears to be running. Run ./stop.sh first if needed."
  exit 0
fi

log "[INFO] Project root: $PROJECT_ROOT"
log "[INFO] PX4_DIR: $PX4_DIR"
log "[INFO] ROS_WS: $ROS_WS"
log "[INFO] Runtime dir: $RUNTIME_DIR"

# 1) Agent first
if [[ "$ENABLE_AGENT" == "1" ]]; then
  start_background "agent" "'$AGENT_CMD' ${AGENT_ARGS}"
  sleep "$AGENT_START_WAIT_SECONDS"
fi

# 2) PX4 + Gazebo
PX4_CMD="cd '$PX4_DIR' && "
if [[ "$HEADLESS" == "1" ]]; then
  PX4_CMD+="HEADLESS=1 "
fi
PX4_CMD+="make px4_sitl '$PX4_TARGET'"

start_background "px4" "$PX4_CMD"

# Wait for PX4 process to exist
wait_for_pattern_process 'px4_sitl_default/bin/px4|[ /]px4([[:space:]]|$)' "$PX4_PROCESS_WAIT_SECONDS" "PX4 process"

# Wait for Gazebo process in gz_x500 flows
wait_for_pattern_process 'gz[[:space:]]+sim|gzserver|ign[[:space:]]+gazebo' "$GZ_PROCESS_WAIT_SECONDS" "Gazebo process"

# Give PX4/Gazebo extra stabilization time before GUI/ROS
sleep "$PX4_START_WAIT_SECONDS"

# 3) QGC after PX4/Gazebo are stable
if [[ "$ENABLE_QGC" == "1" ]]; then
  if [[ -n "$QGC_ENV" ]]; then
    start_background "qgc" "$QGC_ENV '$QGC_APPIMAGE'"
  else
    start_background "qgc" "'$QGC_APPIMAGE'"
  fi
  sleep "$QGC_START_WAIT_SECONDS"
fi

# 4) ROS offboard last
if [[ "$ENABLE_ROS" == "1" ]]; then
  ROS_CMD="source '/opt/ros/$ROS_DISTRO/setup.bash'"
  if [[ -n "$ROS_SETUP_EXTRA" ]]; then
    ROS_CMD+=" && $ROS_SETUP_EXTRA"
  fi
  if [[ -f "$ROS_WS/install/setup.bash" ]]; then
    ROS_CMD+=" && source '$ROS_WS/install/setup.bash'"
  else
    ROS_CMD+=" && source '$ROS_WS/install/local_setup.bash'"
  fi
  ROS_CMD+=" && $OFFBOARD_CMD"
  start_background "ros" "$ROS_CMD"
  sleep "$ROS_START_WAIT_SECONDS"
fi

log "[OK] start sequence finished"
